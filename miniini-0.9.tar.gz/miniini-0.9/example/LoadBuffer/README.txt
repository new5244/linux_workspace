For explanation of code in this example, see the Loading ini data from memory
tutorial in the doc/ directory.
