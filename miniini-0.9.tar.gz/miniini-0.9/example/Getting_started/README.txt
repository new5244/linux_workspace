For explanation of code in this example, see the Getting Started tutorial 
in the doc/ directory.
